SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=false

print_modname() {
 ui_print "#########################"
 ui_print "- 模块: $MODNAME"
 ui_print "- 模块ID: $MODID"
 ui_print "- 模块版本: $MODversion"
 ui_print "- 作者: $MODAUTHOR"
 ui_print "- 说明: 解除部分机型的MIUI ROM对息屏常显显示功能的限制的重置版本
 此作者不更新已退酷安，我发现了进行修改
 可能部分无法使用（测试机型为升级MIUI14之后的Note12 5G）"
 ui_print "#########################"
 ui_print "- 设备相关信息↓"
 ui_print "- SDK: $SDK"
 ui_print "- 设备归属: $Device"
 ui_print "- 设备代号: $device"
 ui_print "- 安卓版本: Android $Android"
 ui_print "- MIUI版本号: $Version"
 ui_print "- MIUI大版本号为: $MIUI"
 ui_print "#########################"
}

on_install() {
# 先卸载模块
ui_print "- 正在卸载模块...别担心，不会影响您的系统文件，仅为执行您已安装模块的uninstall.sh"
ui_print "- 执行的.sh文件路径在您的/data/adb/modules/$MODNAME/uninstall.sh中~"
if [ -d "/data/adb/modules/miuiaul09/" ]; then :
sh /data/adb/modules/$MODNAME/uninstall.sh
fi
sleep 1.0
# 系统版本检测
 if [ $MIUI = "V120" ];then :;elif [ $MIUI = "V125" ];then :;elif [ $MIUI = "V130" ];then :;elif [ $MIUI = "V140" ]; then :
 else ui_print "- 你的设备MIUI版本不符合本模块运行条件" && abort; fi
 if [ $Android = "11" ] || [ $Android = "12" ];then :;elif [ $Android = "13" ];then : 
 else ui_print "- 你的设备系统版本太低了！！" && abort; fi
 if [ $device = "redwood" ] || [ $device = "ruby" ] || [ $device = "rubypro" ]|| [ $device = "sunstone" ] || [ $device = "pissarro" ] || [ $device = "lmi"] || [ $device = "cezanne" ] || [ $device = "alioth" ] || [ $device = "haydn" ] || [ $device = "ares" ] || [ $device = "munch" ] || [ $device = "dipper" ] || [ $device = "equuleus" ] || [ $device = "ursa" ] || [ $device = "cepheus" ] || [ $device = "crux" ] || [ $device = "umi" ] || [ $device = "cmi" ] || [ $device = "thyme" ] || [ $device = "mona" ] || [ $device = "zijin" ] || [ $device = "renoir" ] || [ $device = "sirius" ] || [ $device = "pyxis" ] || [ $device = "tucana" ] || [ $device = "vela" ] || [ $device = "laurus" ] || [ $device = "veux" ] || [ $device = "vangogh" ]; then :
 else ui_print "- 你的设备代号 不支持此模块，故以停止安装！" && abort; fi
 if [ $Device = "Xiaomi" ] || [ $Device = "Redmi" ]; then :
 else ui_print "- 你的机型不支持此模块，故以停止安装！" && abort; fi
 ui_print "- 设备支持安装, 模块正在执行 -"
 ui_print " "
sleep 0.5
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
# 拷贝挂载指定路径文件
cp -rf /system/vendor/etc/device_features/* $MODPATH/system/vendor/etc/device_features/
cp -rf /system/product/etc/device_features/* $MODPATH/system/product/etc/device_features/
########################################################
# 功能开关变量（谨慎修改）
########################################################
keycode0="is_only_support_keycode_goto\">true"
keycode1="is_only_support_keycode_goto\">false"
########################################################
sleep 0.5
sed -i "s/$keycode0/$keycode1/" $MODPATH/system/vendor/etc/device_features/*
sed -i "s/$keycode0/$keycode1/" $MODPATH/system/product/etc/device_features/*
echo "- 解除息屏功能限制 -"
sed -i '/<\/features>/i\    <bool name=\"is_only_support_keycode_goto\">false<\/bool>' $MODPATH/system/product/etc/device_features/*
sed -i '/<\/features>/i\    <bool name=\"is_only_support_keycode_goto\">false<\/bool>' $MODPATH/system/vendor/etc/device_features/*
##################################################################
sleep 0.5
ui_print " "
description=$MODPATH/module.prop
time0=$(date "+%Y-%m-%d %H:%M")
echo "- 当前时间: $time0"
echo "$time0" >> $MODULE
sleep 1.6
}
set_permissions() {
  # Only some special files require specific permissions
  # The default permissions should be good enough for most cases

  # Here are some examples for the set_perm functions:

  # set_perm_recursive  <dirname>                <owner> <group> <dirpermission> <filepermission> <contexts> (default: u:object_r:system_file:s0)
  # set_perm_recursive  $MODPATH/system/lib       0       0       0755            0644

  # set_perm  <filename>                         <owner> <group> <permission> <contexts> (default: u:object_r:system_file:s0)
  # set_perm  $MODPATH/system/bin/app_process32   0       2000    0755         u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0       2000    0755         u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0       0       0644

  # The following is default permissions, DO NOT remove
set_perm_recursive  $MODPATH  0  0  0755  0644
}
